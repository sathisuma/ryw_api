var moment = require('moment');

var sqldb = require('../../config/dbconnect');
var dbutil = require(appRoot + '/utils/dbutils');
var appmdl = require('../models/vendor_mainModel');
const request = require('request');
const axios = require('axios');
var fs = require('fs');

var unirest = require('unirest'); //for whtsapp 

process.env.SECRET_KEY = "thisismysecretkey";



// // vendor strat//

// exports.submitvendorloginCtrl = function (req, res) {
//     appmdl.submitvendorloginmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.getcurrentordersCtrl = function (req, res) {

//     appmdl.getcurrentordersmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.newgetorderdetailsCtrl = function (req, res) {
//     appmdl.newgetorderdetailsmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.updateorderstatusCtrl = function (req, res) {
//     var dataarr = req.body;
//     appmdl.updateorderstatusmdl(req.body, function (err, results) {
//         if (err) {
//             console.log(err);
            
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
        
//         appmdl.getdeliveryplayeridsMdl(dataarr, async function (err, delivery_results) {
//             if (err) {
//                 console.error("Database error:", err);
//                 res.status(500).send({ message: "Database error", error: err });
//                 return;
//             }
        
//             // Extract player_id from each RowDataPacket
//             const delivery_boy_tokes = delivery_results.map(row => row.player_id);
//             console.log(delivery_boy_tokes);
//             try {
//                 const payload = {
//                     title: "New Order",
//                     body: "You have received a new order.",
//                     token: delivery_boy_tokes,  // dynamically set from DB
//                     sound: "custom_sound"
//                 };
        
        
//                 const response = await axios.post(
//                     "http://ec2-13-126-76-184.ap-south-1.compute.amazonaws.com:9632/notifications/v1/sendNotification",
//                     payload
//                 );
//             } catch (error) {
            
//             }
//         });
        
//     });
// }
// exports.getdashboardordersCtrl = function (req, res) {
//     appmdl.getdashboardordersmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.getshoplistCtrl = function (req, res) {
//     appmdl.getshoplistmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }



// exports.getbillinginformationCtrl = function (req, res) {
//     appmdl.getbillinginformationmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.updateshopstatusCtrl = function (req, res) {
//     appmdl.updateshopstatusmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.updatevendorspasswordCtrl = function (req, res) {
//     appmdl.updatevendorspasswordmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.updatepromocodeCtrl = function (req, res) {
//     appmdl.updatepromocodemdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }



// exports.getpromocodesCtrl = function (req, res) {
//     appmdl.getpromocodesmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.deletepromocodeCtrl = function (req, res) {
//     appmdl.deletepromocodemdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.promocodeactiveCtrl = function (req, res) {
//     appmdl.promocodeactivemdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.getproductslistdataCtrl = function (req, res) {
//     if (!req.body.shop_id) {
//         return res.send({ "status": 400, "msg": "shop_id is required" });
//     }
//     appmdl.getproductslistdatamdl(req.body, function (err, results) {
//         if (err) {
           
//             return res.send({ "status": 500, "msg": err.message || err });
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// };
// exports.updateshopproductsCtrl = function (req, res) {
//     appmdl.updateshopproductsmdl(req.body, function (err, results) {
//         if (err) {

//             return res.status(500).json({ "status": 500, "msg": "Failed to update product", "error": err });
//         }
//         res.status(200).json({ 'status': 200, 'data': results, "msg": "Product updated successfully" });
//     });
// };


// exports.postmain_player_id = function (req, res) {
//     // console.log(994 , req.body)
//     var data=req.body
//     appmdl.postmain_player_id(data, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }
// exports.updateproductactiveCtrl = function (req, res) {
//     var data=req.body
 
//     appmdl.updateproductactivesmdl(data, function (err, results) {
//         if (err) {
        
//             return res.status(500).json({ "status": 500, "msg": "Failed to update product", "error": err });
//         }
//         res.status(200).json({ 'status': 200, 'data': results, "msg": "Product updated successfully" });
//     });
// };

// //29032025//
// exports.getshopsforpayments = function (req, res) {
//     appmdl.getshopsforpaymentsmdl(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.getpaymenthistory = function (req, res) {
//     appmdl.getpaymenthistory(req.body, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }


// exports.getuserssubcatgry = function (req, res) {
//     var data=req.body
//     appmdl.getuserssubcatgry(data, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.additemsdetails = function (req, res) {
//     var data=req.body
//         var reviewImgArr = data.item_img
//     //console.log(data, "ctrlfdhgfhjjg");
//     if (reviewImgArr.length != 0) {
//         var image_url = reviewImgArr[0].reviewimg;
//         var array = image_url.split(',');
//         var base64Data = array[1];
//         var datetimestamp = Date.now();
//         var random_number = Math.floor(100000 + Math.random() * 900000);
//         var unicnumber = random_number + '' + datetimestamp;
//         var filetype = reviewImgArr[0].filetype;
//         fs.writeFile("../public_html/control.freshozapcart.com/freshozapcart_images/" + unicnumber + "." + filetype, base64Data, 'base64', function (err) { });
//         imageupload = "https://control.freshozapcart.com/freshozapcart_images/" + unicnumber + '.' + filetype;
//     }
//     else {
//         var imageupload = ' '
//     }
//     appmdl.additemsdetails(data,imageupload, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }

// exports.addsupportfromvendor = function (req, res) {
//     var data=req.body
//     appmdl.addsupportfromvendor(data, function (err, results) {
//         if (err) {
//             res.send({ "status": 500, "msg": err });
//             return;
//         }
//         res.send({ 'status': 200, 'data': results });
//     });
// }


//multitesting api//

// vendor strat//

exports.submitvendorloginCtrl = function (req, res) {
    appmdl.submitvendorloginmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.getcurrentordersCtrl = function (req, res) {

    appmdl.getcurrentordersmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.newgetorderdetailsCtrl = function (req, res) {
    appmdl.newgetorderdetailsmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updateorderstatusCtrl = function (req, res) {
    var dataarr = req.body;
    appmdl.updateorderstatusmdl(req.body, function (err, results) {
        if (err) {
            console.log(err);
            
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
        
        appmdl.getdeliveryplayeridsMdl(dataarr, async function (err, delivery_results) {
            if (err) {
                console.error("Database error:", err);
                res.status(500).send({ message: "Database error", error: err });
                return;
            }
        
            // Extract player_id from each RowDataPacket
            const delivery_boy_tokes = delivery_results.map(row => row.player_id);
            console.log(delivery_boy_tokes);
            try {
                const payload = {
                    title: "New Order",
                    body: "You have received a new order.",
                    token: delivery_boy_tokes,  // dynamically set from DB
                    sound: "custom_sound"
                };
        
        
                const response = await axios.post(
                    "http://ec2-13-126-76-184.ap-south-1.compute.amazonaws.com:9632/notifications/v1/sendNotification",
                    payload
                );
            } catch (error) {
            
            }
        });
        
    });
}
exports.getdashboardordersCtrl = function (req, res) {
    appmdl.getdashboardordersmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.getshoplistCtrl = function (req, res) {
    appmdl.getshoplistmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}



exports.getbillinginformationCtrl = function (req, res) {
    appmdl.getbillinginformationmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.updateshopstatusCtrl = function (req, res) {
    appmdl.updateshopstatusmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updatevendorspasswordCtrl = function (req, res) {
    appmdl.updatevendorspasswordmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updatepromocodeCtrl = function (req, res) {
    appmdl.updatepromocodemdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}



exports.getpromocodesCtrl = function (req, res) {
    appmdl.getpromocodesmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.deletepromocodeCtrl = function (req, res) {
    appmdl.deletepromocodemdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.promocodeactiveCtrl = function (req, res) {
    appmdl.promocodeactivemdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.getproductslistdataCtrl = function (req, res) {
    if (!req.body.shop_id) {
        return res.send({ "status": 400, "msg": "shop_id is required" });
    }
    appmdl.getproductslistdatamdl(req.body, function (err, results) {
        if (err) {
           
            return res.send({ "status": 500, "msg": err.message || err });
        }
        res.send({ 'status': 200, 'data': results });
    });
};
exports.updateshopproductsCtrl = function (req, res) {
    appmdl.updateshopproductsmdl(req.body, function (err, results) {
        if (err) {

            return res.status(500).json({ "status": 500, "msg": "Failed to update product", "error": err });
        }
        res.status(200).json({ 'status': 200, 'data': results, "msg": "Product updated successfully" });
    });
};


exports.postmain_player_id = function (req, res) {
    // console.log(994 , req.body)
    var data=req.body
    appmdl.postmain_player_id(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updateproductactiveCtrl = function (req, res) {
    var data=req.body
 
    appmdl.updateproductactivesmdl(data, function (err, results) {
        if (err) {
        
            return res.status(500).json({ "status": 500, "msg": "Failed to update product", "error": err });
        }
        res.status(200).json({ 'status': 200, 'data': results, "msg": "Product updated successfully" });
    });
};

//29032025//
exports.getshopsforpayments = function (req, res) {
    appmdl.getshopsforpaymentsmdl(req.body, function (err, results) {
        console.log(results)
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.getpaymenthistory = function (req, res) {
    appmdl.getpaymenthistory(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}


exports.getuserssubcatgry = function (req, res) {
    var data=req.body
    appmdl.getuserssubcatgry(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.additemsdetails = function (req, res) {
    var data=req.body
        var reviewImgArr = data.item_img
    //console.log(data, "ctrlfdhgfhjjg");
    if (reviewImgArr.length != 0) {
        var image_url = reviewImgArr[0].reviewimg;
        var array = image_url.split(',');
        var base64Data = array[1];
        var datetimestamp = Date.now();
        var random_number = Math.floor(100000 + Math.random() * 900000);
        var unicnumber = random_number + '' + datetimestamp;
        var filetype = reviewImgArr[0].filetype;
        fs.writeFile("../public_html/control.freshozapcart.com/freshozapcart_images/" + unicnumber + "." + filetype, base64Data, 'base64', function (err) { });
        imageupload = "https://control.freshozapcart.com/freshozapcart_images/" + unicnumber + '.' + filetype;
    }
    else {
        var imageupload = ' '
    }
    appmdl.additemsdetails(data,imageupload, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.addsupportfromvendor = function (req, res) {
    var data=req.body
    appmdl.addsupportfromvendor(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}


exports.getshopidsdata = function (req, res) {
    var data=req.body
    appmdl.getshopidsdata(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}


exports.getcurrentordersbyidCtrl = function (req, res) {

    appmdl.getcurrentordersbyidCmdl(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}



//2605
exports.getdateresultsbydate = function (req, res) {
    appmdl.getdateresultsbydate(req.body, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}









