var sqldb = require('../../config/dbconnect');
var dbutil = require(appRoot + '/utils/dbutils');
var moment = require('moment');






//////////delivery_boy/////

exports.logincheckmdl = function (data, callback) {
    var cntxtDtls = "in logincheckmdl";
    var QRY_TO_EXEC = `SELECT * FROM delivery_boy_t WHERE delivery_boy_mobile_number = ? AND delivery_boy_password = ? AND d_in = '0'`;
    var values = [data.number, data.password];

    if (callback && typeof callback === "function") {
        dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, results) {
            callback(err, results);
        });
    } else {
        return dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls);
    }
};

exports.getnewcurrentordersmdl = function (data, callback) {
 
    var cntxtDtls = "in getnewcurrentordersmdl";
    var QRY_TO_EXEC = `SELECT * FROM order_lst_t WHERE location_id = ? AND order_status ='0' AND d_in = '0'`;
     var values = [data.location_id];
    if (callback && typeof callback === "function") {
        dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, results) {
            callback(err, results);
        });
    } else {
        return dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls);
    }
};

// exports.getcurrentordersmdl = function (data, callback) {
 
//     if (!data || !data.id) {
//         return callback({ status: 400, msg: "Invalid request: ID is required" }, null);
//     }

//     var cntxtDtls = "in getcurrentordersmdl";
//     var QRY_TO_EXEC2 = `SELECT * FROM delivery_boy_t WHERE delivery_boy_active_status=0 AND id=?`;
//     var values2 = [data.id];

//     dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values2, cntxtDtls, function (err, deliveryboyresult) {
//         if (err) return callback(err, null);

//         var QRY_TO_EXEC;
//         var values = [data.id];

//         if (deliveryboyresult.length === 0) {
//             QRY_TO_EXEC = `SELECT o.delivery_boy_id, o.customer_id, o.order_id, o.customer_mobile_number, o.item_count,s.shop_name,s.shop_phone_number,s.shop_latitude,s.shop_longitude,s.shop_address,
//                 o.delivery_charges, o.total_amount, o.grand_total, o.order_type, o.location_id, o.customer_otp, 
//                 o.vendor_otp, o.order_distance, o.order_latitude, o.order_longitude, o.delivery_address, 
//                 DATE_FORMAT(o.order_date_time, "%h:%i") 
//                 FROM order_lst_t as o 
//                 JOIN category_tbl as c on c.id=o.category_id
//                 JOIN shop_list_t as s on s.id=o.shop_id
//                 WHERE o.delivery_boy_id = 1 AND o.order_status IN (2) 
//                 ORDER BY o.id DESC`;
//         } else {
//             QRY_TO_EXEC = `SELECT o.delivery_boy_id, o.customer_id, o.order_id, o.customer_mobile_number, o.item_count,
//                 o.delivery_charges, o.total_amount, o.grand_total, o.order_type, o.location_id, o.customer_otp, 
//                 o.vendor_otp, o.order_distance, o.order_latitude, o.order_longitude, o.delivery_address, 
//                 DATE_FORMAT(o.order_date_time, "%h:%i"), c.category_name, c.category_image,
//                 so.item_name, so.item_image, so.item_price, so.sub_item_count, so.item_total_amount
//                 FROM order_lst_t as o
//                 JOIN category_tbl as c on c.id=o.category_id
//                 JOIN sub_orders_items_t as so on so.order_id=o.id
//                 JOIN shop_list_t as s ON s.id = o.shop_id
//                 WHERE o.delivery_boy_id = ? AND o.order_status IN (1, 2) 
//                 ORDER BY o.id DESC`;
//         }

//         dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, result) {
//             if (err) return callback(err, null);

//             if (!result || result.length === 0) {
//                 return callback(null, { status: 200, delivery_status: deliveryboyresult.length !== 0, data: [] });
//             }

//             callback(null, { status: 200, delivery_status: deliveryboyresult.length !== 0, data: result });
//         });
//     });
// };

exports.getcurrentordersmdl = function (data, callback) {
    if (!data || !data.id) {
        return callback({ status: 400, msg: "Invalid request: ID is required" }, null);
    }
    var cntxtDtls = "in getcurrentordersmdl";
    var checkDeliveryBoyQuery = `SELECT * FROM delivery_boy_t WHERE delivery_boy_active_status = 0 AND id = ?`;
    var deliveryBoyValues = [data.id];
    dbutil.sqlinjection(sqldb.MySQLConPool, checkDeliveryBoyQuery, deliveryBoyValues, cntxtDtls, function (err, deliveryboyresult) {
        if (err) return callback(err, null);
        if (deliveryboyresult.length === 0) {
            return callback(null, { status: 200, delivery_status: false, data: [] });
        }
        // Check if delivery boy has orders with order_status = 2
        var checkOrderQuery = `SELECT o.delivery_boy_id FROM order_lst_t as o WHERE o.delivery_boy_id = ? AND o.order_status IN (2, 8)`;
        var orderValues = [data.id];

        dbutil.sqlinjection(sqldb.MySQLConPool, checkOrderQuery, orderValues, cntxtDtls, function (err, existingOrders) {
            if (err) return callback(err, null);
            var QRY_TO_EXEC;
            var values;
            if (existingOrders.length > 0) {
                // If the delivery boy has orders with order_status = 2, get them
                QRY_TO_EXEC = `SELECT s.shop_name,s.shop_address,s.shop_longitude,s.shop_name,s.shop_phone_number,s.shop_latitude,o.delivery_boy_id, o.customer_id, o.order_id, o.customer_mobile_number, 
                        o.item_count, o.delivery_charges, o.total_amount, o.grand_total, o.order_type, o.location_id, o.id,o.order_status,
                        o.customer_otp, o.vendor_otp, o.order_distance, o.order_latitude, o.order_longitude, 
                        o.delivery_address, DATE_FORMAT(o.order_date_time, "%h:%i") ,so.item_name, so.item_image, so.item_price, so.sub_item_count, so.item_total_amount
                        FROM order_lst_t as o
                          JOIN category_tbl as c on c.id = o.category_id
                        JOIN sub_orders_items_t as so on so.order_id = o.id
                        JOIN shop_list_t as s ON s.id = o.shop_id
                        WHERE o.delivery_boy_id = ? AND o.order_status IN (2, 8)
                        ORDER BY o.id DESC`;
                values = [data.id];
            } else {
                // If no orders with order_status = 2, get new orders with order_status = 1 for the same location_id
                // QRY_TO_EXEC = `SELECT s.shop_name,s.shop_address,s.shop_longitude,s.shop_name,s.shop_phone_number,s.shop_latitude,o.delivery_boy_id, o.customer_id, o.order_id, o.customer_mobile_number, 
                //         o.item_count, o.delivery_charges, o.total_amount, o.grand_total, o.order_type, o.location_id, o.order_status,
                //         o.customer_otp, o.vendor_otp, o.order_distance, o.order_latitude, o.order_longitude, 
                //         o.delivery_address, DATE_FORMAT(o.order_date_time, "%h:%i"), c.category_name, c.category_image, 
                //         so.item_name, so.item_image, so.item_price, so.sub_item_count, so.item_total_amount
                //         FROM order_lst_t as o
                //         JOIN category_tbl as c on c.id = o.category_id
                //         JOIN sub_orders_items_t as so on so.order_id = o.id
                //         JOIN shop_list_t as s ON s.id = o.shop_id
                //         WHERE o.location_id = ? AND o.order_status = 1
                //         ORDER BY o.id DESC`;
                QRY_TO_EXEC=`SELECT s.shop_name,s.shop_address,s.shop_longitude,s.shop_name,s.shop_phone_number,s.shop_latitude,o.delivery_boy_id, o.customer_id, o.order_id, o.customer_mobile_number, 
                        o.item_count, o.delivery_charges, o.total_amount, o.grand_total, o.order_type, o.location_id, o.order_status,o.id,
                        o.customer_otp, o.vendor_otp, o.order_distance, o.order_latitude, o.order_longitude, o.item_count,o.grand_total,o.actual_total_amount,
                        o.delivery_address, DATE_FORMAT(o.order_date_time, "%h:%i"), c.category_name, c.category_image, 
                        o.id
                        FROM order_lst_t as o
                        JOIN category_tbl as c on c.id = o.category_id
                        JOIN shop_list_t as s ON s.id = o.shop_id
                        WHERE o.location_id = ? AND o.order_status = 1 and o.d_in='0'
                        ORDER BY o.id DESC`;
                values = [data.delivery_boy_location_id];
            }
            dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, result) {
                if (err) return callback(err, null);

                return callback(null, { status: 200, delivery_status: true, data: result || [] });
            });
        });
    });
};








exports.getorderdetailsCtrlMdl = function (data, callback) {
    var cntxtDtls = "in getorderdetailsCtrlMdl";
    var QRY_TO_EXEC = `SELECT 
                        s.shop_name, s.shop_unique_id, s.category_id, 
                        f.franchise_name, f.franchise_mobile_number, f.location_id,
                        o.id, o.vendor_otp, o.order_id, 
                        o.item_count, o.total_amount, o.payment_type, o.order_status, 
                        o.order_date_time, o.order_instructions, o.payment_id, 
                        o.slot_timings, o.delivery_address, o.order_latitude, o.order_longitude, 
                        o.delivery_boy_array, o.delivery_boy_latitude, o.delivery_boy_longitude, 
                        DATE_FORMAT(o.order_date, "%d/%m/%Y") AS order_date,  
                        DATE_FORMAT(o.order_date_time, "%h:%i") AS order_time 
                       FROM order_lst_t AS o 
                       JOIN franchise_t AS f ON f.location_id = o.location_id 
                       JOIN shop_list_t AS s ON s.id = o.shop_id  
                       WHERE o.id = ?`;

    var values = [data.order_id];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, orderresult) {
        if (err) return callback(err);
        var QRY_TO_EXEC2 = `SELECT * FROM sub_orders_items_t WHERE order_id = ?`;
        var values2 = [data.order_id]; // Corrected from data.orderid to data.order_id
        dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values2, cntxtDtls, function (err, orderItems) {
            if (err) return callback(err);

            callback(null, { status: 200, orderdata: orderresult, orderitemdata: orderItems });
        });
    });
};


exports.updateorderstatusmdl = function (data, callback) {
    var cntxtDtls = "in updateorderstatusmdl";
     var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var QRY_TO_EXEC = `UPDATE order_lst_t 
        SET delivery_boy_array = ?, delivery_boy_id = ?, order_status = ? ,delivery_accepted_date_time=?
        WHERE order_status = 1 AND id = ?`;
    // Convert deliveryarr to a JSON string before inserting
    var values = [JSON.stringify(data.deliveryarr), data.id, data.order_status,date, data.order_id];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC, values, cntxtDtls, function (err, results) {
        if (err) {
            return callback(err, null);
        }
        callback(null, results);
    });
};


exports.checkdeliveryacceptstatusmdl = function (data, callback) {
    var cntxtDtls = "in checkdeliveryacceptstatusmdl";
    var QRY_TO_EXEC2 = `SELECT d.delivery_boy_player_id, d.delivery_max_service_km, 
        (12742 * asin(sqrt(0.5 - cos((d.delivery_boy_latitude - s.shop_latitude) * 0.01745329251) / 2 + 
        cos(s.shop_latitude * 0.01745329251) * cos(d.delivery_boy_latitude * 0.01745329251) * 
        (1 - cos((d.delivery_boy_longitude - s.shop_longitude) * 0.01745329251)) / 2))) AS distance 
        FROM delivery_boy_t AS d  
        JOIN order_lst_t AS o ON o.id = ?  
        JOIN shop_list_t AS s ON s.id = o.shop_id                 
        WHERE o.order_status = 1 AND d.active_status = 0 AND d.id = ?  
        HAVING distance < d.delivery_max_service_km`;
    
    var values = [data.order_id, data.id];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};


exports.updatedeliverylatlngmdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in updatedeliverylatlngmdl";
    var QRY_TO_EXEC2 = `UPDATE delivery_boy_t SET delivery_boy_latitude= ?, delivery_boy_longitude= ?, 
                        delivery_boy_lat_lng_time= ? WHERE id = ?`;
    var values = [data.latitude, data.longitude, date, data.id];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};



exports.updatedeliveryotpmdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in updatedeliveryotpmdl";
    var QRY_TO_EXEC2 = `UPDATE order_lst_t SET order_status= '2',deliveryboy_pickup_time= ?,vendor_otp=? WHERE  id =?`;
    var values = [date,data.vendor_otp, data.id];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};



exports.completedordermdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in completedordermdl";
    var QRY_TO_EXEC2 = `UPDATE order_lst_t SET order_status= '3',customer_otp='0' WHERE delivery_boy_id=? and customer_otp=? and id=?`;
    var values = [data.delivery_id,data.delivery_otp, data.order_id];
    console.log(QRY_TO_EXEC2,values)
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};

exports.getprofiledataCtrlmdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in getprofiledataCtrlmdl";
    var QRY_TO_EXEC2 = `select * from delivery_boy_t whered_in='0' and id=?`;
    var values = [data.id];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};




exports.updateprofiledatamdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in updateprofiledatamdl";
    var QRY_TO_EXEC2 = `UPDATE delivery_boy_t SET delivery_boy_name= ?,delivery_boy_mobile_number=?,delivery_boy_password=?,delivery_boy_address=? WHERE id=?`;
    var values = [data.name,data.mobilenumber, data.password,data.address,data.id];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};







exports.updateoderstatdatamdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in updateoderstatdatamdl";
    var QRY_TO_EXEC2 = `UPDATE order_lst_t SET order_status='2',vendor_otp='0' WHERE id=?`;
    var values = [data.id];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};



exports.updatelatlongsdatamdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in updatelatlongsdatamdl";

    var QRY_TO_EXEC2 = `
        UPDATE order_lst_t 
        SET delivery_boy_latitude = ?, delivery_boy_longitude = ? 
        WHERE id = ?;

        UPDATE delivery_boy_t 
        SET delivery_boy_latitude = ?, delivery_boy_longitude = ?
        WHERE id = ?;
    `;

    var values = [
        data.latitude, data.longitude, data.order_id,  // First UPDATE statement
        data.latitude, data.longitude,  data.id  // Second UPDATE statement (with time)
    ];

    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};




exports.getordersdatewisemdl = function (data, callback) {

    var cntxtDtls = "in getordersdatewisemdl";
    var QRY_TO_EXEC2 = `select s.shop_name, s.shop_unique_id, s.category_id, 
                        f.franchise_name, f.franchise_mobile_number, f.location_id,
                        o.id, o.vendor_otp, o.order_id, 
                        o.item_count, o.total_amount, o.payment_type, o.order_status, 
                        o.order_date_time, o.order_instructions, o.payment_id, 
                        o.slot_timings, o.delivery_address, o.order_latitude, o.order_longitude, 
                        o.delivery_boy_array, o.delivery_boy_latitude, o.delivery_boy_longitude, 
                        DATE_FORMAT(o.order_date, "%d/%m/%Y") AS order_date  FROM order_lst_t AS o 
  JOIN franchise_t AS f ON f.location_id = o.location_id 
  JOIN shop_list_t AS s ON s.id = o.shop_id
     WHERE  o.delivery_boy_id=? and o.order_date >=? and o.order_date <=? AND o.order_status in (3,8,5);`;
    var values = [data.emp_id,data.f_date,data.t_date];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};

exports.updateplayeridmdl = function (data, callback) {
    var date = moment().utcOffset("+05:30").format("YYYY-MM-DD HH:mm:ss");
    var cntxtDtls = "in updateplayeridmdl";
    var QRY_TO_EXEC2 = `UPDATE delivery_boy_t SET delivery_boy_player_id=? WHERE id=?`;
    var values = [data.player_id,data.id];
    dbutil.sqlinjection(sqldb.MySQLConPool, QRY_TO_EXEC2, values, cntxtDtls, function (err, delres) {
        if (err) {
            return callback(err, null);
        }
        callback(null, { status: 200, data: delres });
    });
};










