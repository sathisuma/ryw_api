var moment = require('moment');

var sqldb = require('../../config/dbconnect');
var dbutil = require(appRoot + '/utils/dbutils');
var appmdl = require('../models/delivery_mainModel');
const request = require('request');



process.env.SECRET_KEY = "thisismysecretkey";



//// delivery_boy////
exports.logincheckCtrl = function (req, res) {
    var data = req.body;
  
    // Validate input: Check if both number and password are provided
    if (!data.number || !data.password) {
        res.send({ "status": 500, "msg": "Mobile number and password are required" });
        return;
    }
    appmdl.logincheckmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }

        // Check if any results are returned (i.e., valid credentials)
        if (results.length > 0) {
            res.send({ "status": 200, "data": results });
        } else {
            res.send({ "status": 500, "msg": "Invalid credentials" });
        }
    });
};

exports.getcurrentordersCtrl = function (req, res) {
    var data = req.body;
    appmdl.getcurrentordersmdl(data, function (err, results) {
        if (err) {
            console.error("Error:", err);
            return res.status(err.status || 500).send({ status: 500, msg: err.msg || "Internal Server Error" });
        }
        res.status(200).send(results);
    });
};



exports.getnewcurrentordersCtrl = function (req, res) {
    var data=req.body;
   
    appmdl.getnewcurrentordersmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.getorderdetailsCtrl = function (req, res) {
    var data=req.body
    appmdl.getorderdetailsCtrlMdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}


exports.updateorderstatusCtrl = function (req, res) {
    var data=req.body
    appmdl.updateorderstatusmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.checkdeliveryacceptstatusCtrl = function (req, res) {
    var data=req.body
    appmdl.checkdeliveryacceptstatusmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.updatedeliverylatlngCtrl = function (req, res) {
    var data=req.body
    appmdl.updatedeliverylatlngmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updatedeliveryotpCtrl = function (req, res) {
    var data=req.body
    appmdl.updatedeliveryotpmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.completedorderCtrl = function (req, res) {
    var data=req.body
    appmdl.completedordermdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.getprofiledataCtrl = function (req, res) {
    var data=req.body
    appmdl.getprofiledataCtrlmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.updateprofiledataCtrl = function (req, res) {
    var data=req.body
    appmdl.updateprofiledatamdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updateoderstatdataCtrl = function (req, res) {
    var data=req.body
    appmdl.updateoderstatdatamdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}
exports.updatelatlongsdataCtrl = function (req, res) {
    var data=req.body
    appmdl.updatelatlongsdatamdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.getordersdatewiseCtrl = function (req, res) {
    var data=req.body
    appmdl.getordersdatewisemdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}

exports.updateplayeridCtrl = function (req, res) {
    var data=req.body
    appmdl.updateplayeridmdl(data, function (err, results) {
        if (err) {
            res.send({ "status": 500, "msg": err });
            return;
        }
        res.send({ 'status': 200, 'data': results });
    });
}












